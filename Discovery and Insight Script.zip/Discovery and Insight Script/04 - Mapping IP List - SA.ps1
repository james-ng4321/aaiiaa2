﻿#The scirpt has 2 parts
#1. Common Function
#2. Business Logic

### Common Function ###

#Write Lof File for trouble shoot
$currentDatetime =Get-Date -Format "ddMMyyyyHHmm"
$Logfile = './04 Mapping/Script Log/Mapping Log Script Log File - SA '  + $currentDatetime +  '.Log'

function WriteLog
{
    Param ([string]$LogString)
    $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
    $LogMessage = "$Stamp $LogString"
    Add-content $LogFile -value $LogMessage
}


function IPInRange {
    [cmdletbinding()]
    [outputtype([System.Boolean])]
    param(
        # IP Address to find.
        [parameter(Mandatory,
                   Position=0)]
        [validatescript({
            ([System.Net.IPAddress]$_).AddressFamily -eq 'InterNetwork'
        })]
        [string]
        $IPAddress,
 
        # Range in which to search using CIDR notation. (ippaddr/bits)
        [parameter(Mandatory,
                   Position=1)]
        [validatescript({
            $IP   = ($_ -split '/')[0]
            $Bits = ($_ -split '/')[1]
 
            (([System.Net.IPAddress]($IP)).AddressFamily -eq 'InterNetwork')
 
            if (-not($Bits)) {
                throw 'Missing CIDR notiation.'
            } elseif (-not(0..32 -contains [int]$Bits)) {
                throw 'Invalid CIDR notation. The valid bit range is 0 to 32.'
            }
        })]
        [alias('CIDR')]
        [string]
        $Range
    )
 
    # Split range into the address and the CIDR notation
    [String]$CIDRAddress = $Range.Split('/')[0]
    [int]$CIDRBits       = $Range.Split('/')[1]
 
    # Address from range and the search address are converted to Int32 and the full mask is calculated from the CIDR notation.
    [int]$BaseAddress    = [System.BitConverter]::ToInt32((([System.Net.IPAddress]::Parse($CIDRAddress)).GetAddressBytes()), 0)
    [int]$Address        = [System.BitConverter]::ToInt32(([System.Net.IPAddress]::Parse($IPAddress).GetAddressBytes()), 0)
    [int]$Mask           = [System.Net.IPAddress]::HostToNetworkOrder(-1 -shl ( 32 - $CIDRBits))
 
    # Determine whether the address is in the range.
    if (($BaseAddress -band $Mask) -eq ($Address -band $Mask)) {
        $true
    } else {
        $false
    }
}

### Business Logic ###



#Retireve the source file
$InitialResultList = Import-csv './03 Generate Log/03 – Generate Log By Count-SA.CSV' 

#AIA Known IP
$AIAKnownIP  = Import-csv './04 Mapping/Mapping Sources/AIA Sources.csv'

#Microsoft Azure Data Center Public IP List
$AzureDataCenterIPList = Import-csv './04 Mapping/Mapping Sources/Microsoft Azure Datacenter Public IPs.csv'


#Microsoft LogicApp PowerPlatform Pulic IP in Asia Region
$NonTeustedAzureService = Import-csv './04 Mapping/Mapping Sources/Microsoft LogicApp PowerPlatform IP Asia Region.csv'




#Init the output File
$outfile = './04 Mapping/04 – Mapping Log-SA-'  + $currentDatetime +  '.CSV'
$newcsv = {} | Select "CallerIpAddress","Whitelist (Yes/No)","Account Name","Service Type","Status Text","ResourceId","Count","Allow Public Access","IP White List","VnetRules","PrivateEndpoint","Resource Taggings","AddressType","VNET SUBNET","VNET Name","SUBNET Name" ,"Remark","Application Contact","App Owner"  | Export-Csv  -NoTypeInformation $outfile


$i=1
foreach($line in $InitialResultList)
{ 
    $foundIP = 0
    $AddressType = ''
    $VNETSUBNET = ''
    $VNETNAME = ''
    $SUBNETNAME = ''
    $Remark = ''



    If( $line.CallerIpAddress -ne '')
    {

        "Inserting Line: " + $i 
    $logInfo = "Inserting Line: " + $i 
    WriteLog  $logInfo 
        
        #Check the caller IP is in LogicApp PowerPlatform Pulic IP in Asia Region
        If($foundIP -eq 0 )
        {
           foreach($NonTeustedAzureServiceLine in $NonTeustedAzureService)
           {
           

              # $fromIP = [CallerIpAddress]$AzureDCLine.Prefix
              # $targetIP =  [CallerIpAddress]$line.CallerCallerIpAddress
               #$AzureDataCenterIPList.Prefix
               if ($NonTeustedAzureServiceLine.ServiceIP -eq $line.CallerIpAddress)
               {
                   $foundIP = 1
                   $AddressType = 'LogicApp PowerPlatform IP'
                   $VNETSUBNET = $NonTeustedAzureServiceLine.ServiceIP
                   $Remark = $NonTeustedAzureServiceLine.Remark
                   break
               }
            }
        }
        
        #Check the caller IP is in Azure Data Center IP List
        If($foundIP -eq 0 )
        {
           foreach($AzureDCLine in $AzureDataCenterIPList)
           {
        

              # $fromIP = [CallerIpAddress]$AzureDCLine.Prefix
              # $targetIP =  [CallerIpAddress]$line.CallerCallerIpAddress
               #$AzureDataCenterIPList.Prefix
               If(IPinRange -IPAddress   $line.CallerIpAddress -Range $AzureDCLine.Prefix)
               {
                   $foundIP = 1
                   $AddressType = 'Azure Data Center'
                   $VNETSUBNET = $AzureDCLine.Prefix
                   $Remark = $AzureDCLine.Type
                   break
               }
            }
        }
        

        #Check the caller IP is from AIA IP List
        If($foundIP -eq 0 )
        {
            foreach($AIAKnownIPLine in $AIAKnownIP)
            { 
                #Check the caller IP is in Public IP address (HK01)
                if ( $AIAKnownIPLine."Type" -eq "Public IP address (HK01)"  )
                {
                    #$AIAKnownIPLine."Value" + "|" + $AIAKnownIPLine."Value".Contains("/")
                    if ($AIAKnownIPLine."Value".Contains("/"))
                    {
                        if ((IPinRange -IPAddress $line.CallerIpAddress -Range $AIAKnownIPLine."Value"))
                        {
                            $foundIP = 1
                            $AddressType = 'Public IP address (HK01)'
                            $Remark = $AIAKnownIPLine.'Name'
                            break
                        }
                    }
                    else
                    {
                        if ($AIAKnownIPLine."Value" -eq $line.CallerIpAddress)
                        {
                            $foundIP = 1
                            $AddressType = 'Public IP address (HK01)'
                            $Remark = $AIAKnownIPLine.'Name'
                            break
                        }
                    }
                }

                
                 #Check the caller IP is in AIA Global IP
                 If($foundIP -eq 0 )
                 {

                    If($AIAKnownIPLine."Type" -eq "AIA Global IP")
                    {
                        if($AIAKnownIPLine."Value".Contains("/"))
                        {
                            if ((IPinRange -IPAddress $line.CallerIpAddress -Range $AIAKnownIPLine."Value"))
                            {
                                $foundIP = 1
                                $AddressType = "AIA Global IP"
                                $VNETSUBNET = $AIAKnownIPLine."Value".Trim()
                                 $Remark = $AIAKnownIPLine."Name".Trim() + " " + $AIAKnownIPLine."Remark1"
                                break
                            }
                        }
                        else
                        {
                            if ($AIAKnownIPLine."Value" -eq $line.CallerIpAddress)
                            {
                                $foundIP = 1
                                $AddressType = "AIA Global IP"
                                $VNETSUBNET = $AIAKnownIPLine."Value".Trim()
                                $Remark = $AIAKnownIPLine."Name".Trim() + " " + $AIAKnownIPLine."Remark1"
                                break
                            }
                        }
                    }
                 }


                 #Check the caller IP is in Zscaler
                 If($foundIP -eq 0 )
                 {
                      If($AIAKnownIPLine."Type" -eq "Zscaler")
                      {
                        if($AIAKnownIPLine."Value".Contains("/"))
                        {
                            if ((IPinRange -IPAddress $line.CallerIpAddress -Range $AIAKnownIPLine."Value"))
                            {
                                $foundIP = 1
                                $AddressType = 'Zscaler'
                                $VNETSUBNET = $AIAKnownIPLine."Value".Trim()
                                break
                            }
                        }
                        else
                        {
                            if ($AIAKnownIPLine."Value" -eq $line.CallerIpAddress)
                            {
                                 $foundIP = 1
                                $AddressType = 'Zscaler'
                                $VNETSUBNET = $AIAKnownIPLine."Value".Trim()
                                break
                            }
                        }
                       }
                 }

                 #Check the caller IP is in AIA PIP List
                 If($foundIP -eq 0 )
                 {
                      If($AIAKnownIPLine."Type" -eq "AIA PIP List")
                      {
                        if($AIAKnownIPLine."Value".Contains("/"))
                        {
                            if ((IPinRange -IPAddress $line.CallerIpAddress -Range $AIAKnownIPLine."Value"))
                            {
                                $foundIP = 1
                                $AddressType = 'AIA PIP List'
                                $VNETSUBNET = $AIAKnownIPLine."Value".Trim()
                                $Remark = $AIAKnownIPLine."Name".Trim() + " " + $AIAKnownIPLine."Remark1"
                                break
                            }
                        }
                        else
                        {
                            if ($AIAKnownIPLine."Value" -eq $line.CallerIpAddress)
                            {
                                 $foundIP = 1
                                $AddressType = 'AIA PIP List'
                                $VNETSUBNET = $AIAKnownIPLine."Value".Trim()
                                $Remark = $AIAKnownIPLine."Name".Trim() + " " + $AIAKnownIPLine."Remark1"
                                break
                            }
                        }
                       }
                 }
                
                 #Check the caller IP is in AIA HK01 VNet/SubNet
                 If($foundIP -eq 0 )
                {
                    If($AIAKnownIPLine."Type" -eq "AIA HK01 VNet/SubNet" )
                    {
                        if($AIAKnownIPLine."Value".Contains("/"))
                        {
                          if((IPinRange -IPAddress $line.CallerIpAddress -Range $AIAKnownIPLine."Value"))
                          {
                            $foundIP = 1
                            $AddressType = 'AIA HK01 VNet/SubNet'
                            $VNETSUBNET = $AIAKnownIPLine."Value".Trim()
                            $Remark = $AIAKnownIPLine.Remark1.Trim()
                            $VNETNAME = $AIAKnownIPLine.Remark2.Trim()
                            $SUBNETNAME = $AIAKnownIPLine.Remark3.Trim()
                            break
                          }
                        }
                        else
                        {
                            if ($AIAKnownIPLine."Value" -eq $line.CallerIpAddress)
                            {
                                $foundIP = 1
                                $AddressType = 'AIA HK01 VNet/SubNet'
                                $VNETSUBNET = $AIAKnownIPLine."Value".Trim()
                                $Remark = $AIAKnownIPLine.Remark1.Trim()
                                $VNETNAME = $AIAKnownIPLine.Remark2.Trim()
                                $SUBNETNAME = $AIAKnownIPLine.Remark3.Trim()
                                break
                            }
                        }
                    }
                }
            }

        }

      

        If($foundIP -eq 0)
        {
            $AddressType = 'Others'
        }

        $NewLine = "`"{0}`",`"{1}`",`"{2}`",`"{3}`",`"{4}`",`"{5}`",`"{6}`",`"{7}`",`"{8}`",`"{9}`",`"{10}`",`"{11}`",`"{12}`",`"{13}`",`"{14}`",`"{15}`",`"{16}`",`"{17}`",`"{18}`"" -f $line.CallerIpAddress,,' ',$line.'AccountName',$line.'ServiceType',$line.'StatusText', $line.'_ResourceId', $line.Count,$line.'AllowPublicAccess',$line.'IPwhitelist',$line.'VnetRules',$line.'PrivateEndpoint',$line.Tags,$AddressType, $VNETSUBNET,$VNETNAME, $SUBNETNAME, $Remark,$line.'ApplicationContact',$line.'AppOwner' 
        $NewLine | add-content -path $outfile
      

        #$line.CallerCallerIpAddress
   
        #$csvfile = Import-Csv $outfile
       # $csvfile. = $line.CallerCallerIpAddress
  
   }
   else
   {
       "Inserting Line: " + $i  + " Error: IP Address is missing. It value is "+   $line.CallerIpAddress
       $logInfo = "Inserting Line: " + $i  + " Error: IP Address is missing. It value is "+   $line.CallerIpAddress
      WriteLog   $logInfo
   }

     $i++;
}

   #Export-Csv  $outputLine

