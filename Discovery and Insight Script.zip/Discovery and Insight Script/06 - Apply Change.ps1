﻿#Point to file with Client Hostname and ipaddress fields. (Headers = hostname and ipaddress
# Connect-AzAccount
Connect-AzAccount -TenantId 7f2c1900-9fd4-4b89-91d3-79a649996f0a -WarningAction SilentlyContinue


$csvDelimiterSymbol = ','
$originalCsv = Import-csv '05 - BuildSheet.csv' -Delimiter $csvDelimiterSymbol
$IPDelimiterSymbol = ','
$VnetDelimiterSymbol = ','
$log =".\ChangesLog.txt"
Stop-Transcript -ErrorAction SilentlyContinue
Start-Transcript $log
$i=1

$originalCsv | ForEach-Object{
    $i ++
    Write-Host( "*** Start to configure "+ $_.ResourceName + " on CSV Row " + $i +" ***")
    if($_.ResourceType -eq "SA"){

        $row=$_.resourcename
        $resourcegroupname=(get-azstorageaccount|Where-Object {$_.storageaccountname -eq $row}).ResourceGroupName
        if(!([string]::IsNullOrWhiteSpace($resourcegroupname))) {
        #access type(public network access)
        if($_.AccessType -eq "PublicAccess"){

            Set-AzStorageAccount -name $_.resourcename -ResourceGroupName $resourcegroupname -PublicNetworkAccess Enabled -ErrorAction Stop
            Update-AzStorageAccountNetworkRuleSet -ResourceGroupName $resourcegroupname -Name $_.resourcename -DefaultAction Allow -ErrorAction Stop -Bypass AzureServices
            Write-host("Update public network access to PublicAccess for "+$_.resourcename)
        }
        elseif($_.AccessType -eq "RestrictAccess"){
            Set-AzStorageAccount -name $_.resourcename -ResourceGroupName $resourcegroupname -PublicNetworkAccess Enabled -ErrorAction Stop
            Update-AzStorageAccountNetworkRuleSet -ResourceGroupName $resourcegroupname -Name $_.resourcename -DefaultAction Deny -ErrorAction Stop -Bypass AzureServices
            Write-host("Update public network access to RestrictAccess for "+$_.resourcename )
        }
        elseif($_.AccessType -eq "DisableAccess"){

            Set-AzStorageAccount -name $_.resourcename -ResourceGroupName $resourcegroupname -PublicNetworkAccess Disabled -ErrorAction Stop
            Update-AzStorageAccountNetworkRuleSet -ResourceGroupName $resourcegroupname -Name $_.resourcename -DefaultAction Deny -ErrorAction Stop -Bypass AzureServices
            Write-host("Update public network access to DisableAccess for "+$_.resourcename )
        }
        #endregion

        #region 
        #virtual networks
        #VnetRule from CSV should have list of the names of the virtual network separated by delimiters
        #set the default rule to deny, or network rules have no effect.

        $vNetRuleString = $_.subnetname
        if(!([string]::IsNullOrWhiteSpace($vNetRuleString))) {
            Write-host("Start to configure Vnet "+$_.resourcename +" Vnet - SubnetName: "+$_.subnetname)
            $vNetRuleArray = $vNetRuleString.Split($VnetDelimiterSymbol)
            
                    foreach($subnetname in $vNetRuleArray){
                        $subnet1=((Get-AzVirtualNetwork).Subnets | Where-Object {$_.name -eq $subnetname})
                        if($subnet1){
                        Add-AzStorageAccountNetworkRule -ResourceGroupName $resourceGroupName -Name $_.ResourceName -VirtualNetworkResourceId $subnet1.id 
                        }else{echo "Error: SubnetName "+$subnetname+" not found"}
                    }                    

        }


        #endregion

        #region
        #firewall
        $firewallRuleString = $_.FirewallRule
        $firewallRuleArray = $firewallRuleString.Split($IPDelimiterSymbol)
        if(!([string]::IsNullOrWhiteSpace($firewallRuleString))) {
        foreach($firewallRule in $firewallRuleArray){
            if ($firewallRule){
            #powershell command to set firewall rules
            Add-AzStorageAccountNetworkRule -name $_.resourceName -ResourceGroupName $ResourceGroupName -IPAddressOrRange $firewallRule.trim() 
            Write-Host("Start to configure Firewall rule: $firewallRule for "+$_.resourceName)
            }
        }
        }
        }
        else {
            Write-Host("Error: "+$_.ResourceName+ " was not found")
        }
        #endregion

    }
    elseif($_.ResourceType -eq "KV"){
        $resourcegroupname=(Get-AzKeyVault -name $_.resourcename).ResourceGroupName
        if(!([string]::IsNullOrWhiteSpace($resourcegroupname))) {
        #region 
        #access type(public network access)
        if($_.AccessType -eq "PublicAccess"){
            Update-AzKeyVaultNetworkRuleSet -VaultName $_.resourcename -DefaultAction Allow -Bypass AzureServices
            Write-host("Update public network access to PublicAccess for "+$_.resourcename)
        }
        elseif($_.AccessType -eq "RestrictAccess"){
            Update-AzKeyVaultNetworkRuleSet -VaultName $_.resourcename -DefaultAction Deny -Bypass AzureServices
            Write-host("Update public network access to RestrictAccess for "+$_.resourcename )
        }
        elseif($_.AccessType -eq "DisableAccess"){
            Update-AzKeyVaultNetworkRuleSet -VaultName $_.resourcename -DefaultAction Deny -Bypass AzureServices
            Write-host("Update public network access to DisableAccess for "+$_.resourcename )
        }
        #endregion

        #region 
        #virtual networks
        #VnetRule from CSV should have list of the names of the virtual network separated by delimiters
        #subnets will be applied to each virtual network in the same record entry 
        #set the default rule to deny, or network rules have no effect.
        $vNetRuleString = $_.SubnetName
        if(!([string]::IsNullOrWhiteSpace($vNetRuleString))) {
            Write-host("Start to configure Vnet "+$_.resourcename +" Vnet - SubnetName: "+$_.subnetname)
            #get list of vnetsubnets  
            $vNetRuleArray = $vNetRuleString.Split($VnetDelimiterSymbol)              
                    foreach($subnetname in $vNetRuleArray){
                        $subnet1=((Get-AzVirtualNetwork).Subnets | Where-Object {$_.name -eq $subnetname})
                        if($subnet1){
                        #add subnet to keyvault network rule
                        Add-AzKeyVaultNetworkRule -ResourceGroupName $resourceGroupName -VaultName $_.ResourceName -VirtualNetworkResourceId $subnet1.id
                        }else{write-host ("Error: SubnetName "+$subnetname+" not found")}
                    }                    

        }


        #endregion

        #region
        #firewall
        $firewallRuleString = $_.FirewallRule
        $firewallRuleArray = $firewallRuleString.Split($IPDelimiterSymbol)
        if(!([string]::IsNullOrWhiteSpace($firewallRuleString))) {
        foreach($firewallRule in $firewallRuleArray){
            if  ($firewallRule -as [ipaddress] -as [bool]){$firewallRule+='/32'}
            #powershell command to set firewall rules
            if ($firewallRule){
            Add-AzKeyVaultNetworkRule -VaultName $_.resourcename -IpAddressRange $firewallRule.trim()
            Write-Host("Start to configure Firewall rule: $firewallRule for "+$_.resourceName)
            }
        }  
        }
        }else {Write-Host("Error: "+$_.ResourceName+ " was not found")}

        #endregion
    }      
    Write-Host( "*** Ended to configure "+ $_.ResourceName + " on CSV Row " + $i +" ***")
}

Stop-Transcript
Write-Host("Script END")