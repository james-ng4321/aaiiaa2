﻿# Make sure you are authenticated with 
# Connect-AzAccount
#Connect-AzAccount -TenantId 7f2c1900-9fd4-4b89-91d3-79a649996f0a -WarningAction SilentlyContinue

# LA workspace Resource ID
[string]$WorkspaceResourceID = '/subscriptions/fc6e9d72-7f73-4a05-83de-44204d69d3f7/resourcegroups/rg-go02-sea-d-gis-sasmgmt/providers/microsoft.operationalinsights/workspaces/la-go02-eas-d-gissasmgmt-workspace01'
[string]$WorkspaceResourceID2 = '/subscriptions/fc6e9d72-7f73-4a05-83de-44204d69d3f7/resourcegroups/rg-go02-sea-d-gis-sasmgmt/providers/microsoft.operationalinsights/workspaces/la-go02-sea-d-gissasmgmt-workspace01'
# CSV file
$inputCsvFile = "01 - Target item-KV.csv"

# CSV path
$inputPath = ".\01 Source"
# import csv
$inputCsv = Import-CSV -Path $inputPath\$inputCsvFile -Delimiter ";"
$SAlist = $inputCsv |
select ResourceName,ApplicationContact,AppOwner|
Sort-Object Resourcename -Unique
# for output csv
$Results2 = @()
$Privateendpoint=Get-AzPrivateendpoint
#create folder
#$date=$((Get-Date).ToString('yyyy-MM-dd-hhmm'))
#New-Item -ItemType Directory -Path ".\Generate Log SA-$date" -erroraction 'silentlycontinue'
New-Item -ItemType Directory -Path ".\02 Validate" -erroraction 'silentlycontinue'
echo "Start to Validate KV."
# Loop SAlist - List of SA which is unique
 foreach ( $Row in $SAlist )
{
$Results = Get-AzKeyVault -name $Row.ResourceName
$WorkspaceResourceID4 = (Get-AzDiagnosticSetting -ResourceId $Results.ResourceId -WarningAction SilentlyContinue).workspaceid
$DiagnosticSetting1="False"
foreach ($WorkspaceResourceID3 in $WorkspaceResourceID4){ if(($WorkspaceResourceID3.Trim() -eq $WorkspaceResourceID2) -Or ($WorkspaceResourceID3.Trim() -eq $WorkspaceResourceID)){$DiagnosticSetting1='True';break}}
#$WorkspaceResourceID3=$WorkspaceResourceID5.Trim()
$Results2 += New-Object PSObject -property @{ 
ResourceName = $Results.VaultName
ResourceGroup = $Results.ResourceGroupName
Location = $Results.Location
ResourceID = $Results.ResourceId
Tags = $Results.TagsTable
#PublicNetworkAccess = $Results.PublicNetworkAccess
DiagnosticSetting = $DiagnosticSetting1
IPwhitelist = $Results.NetworkAcls.IpAddressRangesText
VnetRules = (($Results.NetworkAcls.VirtualNetworkResourceIds|ForEach-Object{if($_){$_.Replace('microsoft.network/virtualnetworks','Microsoft.Network/virtualNetworks')}})|Foreach-object {(Get-AzVirtualNetworkSubnetConfig -ResourceId $_).AddressPrefix}) -join ', ' 
AllowPublicAccess = if(($Results.PublicNetworkAccess -eq 'Enabled')-and($Results.NetworkAcls.DefaultAction -eq 'Allow')){'True'}else{'False'}
#RestrictAccess = if(($Results.PublicNetworkAccess -eq 'Enabled') -and ($Results.NetworkAcls.DefaultAction -eq 'Deny')){'True'}else{'False'}
#DisableAccess = if(($Results.PublicNetworkAccess -eq "Disable")-and ($Results.NetworkAcls.DefaultAction -eq "Deny")){'True'}else{'False'}
PrivateEndpoint = foreach ($pe in $Privateendpoint){if ($pe.privatelinkserviceconnections.privatelinkserviceid -eq $Results.ResourceId){'True';break}}
TrustedService = $Results.NetworkAcls.Bypass
ApplicationContact = $row.ApplicationContact
AppOwner = $row.AppOwner
}
}
$path= ".\02 Validate\02 - Validate Result-KV.CSV"
$Results2 | select ResourceName,ResourceGroup,ResourceID,Location,DiagnosticSetting,AllowPublicAccess,IPwhitelist,VnetRules,PrivateEndpoint,TrustedService,Tags,ApplicationContact,AppOwner | Export-Csv -Path $path -NoTypeInformation
echo "02 - Validate Result-KV.CSV is generated !"
